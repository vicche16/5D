$("document").ready(function scrolldown() {			
											   
		$('html, body').animate({
			scrollTop: $(".container").delay(1000).offset().top
		}, 700);
		window.onload = scrollTop;				   									   
});